
void* token_init(void *val);

void token_engine(unsigned long long token_rate);

void interrupt_token();
